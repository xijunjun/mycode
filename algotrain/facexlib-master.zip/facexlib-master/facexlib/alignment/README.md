
## Landmarks

- 5 landmarks

<p align="center">
  <img src="../../assets/landmarks_5.jpg", height="300">
</p>

- 68 landmarks

<p align="center">
  <img src="../../assets/landmarks_68.png", height="400">
</p>

- 98 landmarks

<p align="center">
  <img src="../../assets/landmarks_98.png", height="500">
</p>
